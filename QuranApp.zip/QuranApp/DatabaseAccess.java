package com.example.quran_app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseAccess {
    private final SQLiteOpenHelper openHelper;
    private SQLiteDatabase db;
    private static DatabaseAccess instance;
    Cursor c=null;
    //private constructor so that object creation from outside of class can be avoided
    private DatabaseAccess(Context context){
        this.openHelper=new DatabaseOpenHelper(context);
    }
    public static DatabaseAccess getInstance(Context context)
    {
        if(instance==null)
        {
            instance=new DatabaseAccess(context);
        }
        return instance;
    }
    public void open()
    {
        this.db=openHelper.getWritableDatabase();
    }
    public void close()
    {
        if(db!=null)
        {
          this.db.close();
        }
    }
    public String getTranslation(int id)
    {
        c=db.rawQuery("Select MehmoodulHassan from tayah where SuraID = "+id+"",new String[]{});
         StringBuffer buffer =new StringBuffer();
         while(c.moveToNext()){
             String address=c.getString(0);
             buffer.append(""+address);

         }
         return buffer.toString();
    }
    public ArrayList getSurahAyahs(int Surah_no)
    {
        c=db.rawQuery("Select ArabicText,FatehMuhammadJalandhri,DrMohsinKhan from tayah where SuraID = "+Surah_no+"",new String[]{});
        ArrayList<Ayah> SurahAyahs=new ArrayList<>();
        Ayah ayahs;
        while(c.moveToNext()){
            String ayah=c.getString(0);
            String urduTranslation=c.getString(1);
            String englishTranslation=c.getString(2);
            ayahs=new Ayah(ayah,urduTranslation,englishTranslation);
            SurahAyahs.add(ayahs);
        }
        return SurahAyahs;
    }

    public ArrayList getParahAyahs(int parah_no)
    {
        c=db.rawQuery("Select ArabicText,FatehMuhammadJalandhri,DrMohsinKhan from tayah where ParaID = "+parah_no+"",new String[]{});
        ArrayList<Ayah> ParahAyahs=new ArrayList<>();
        Ayah ayahs;
        while(c.moveToNext()){
            String ayah=c.getString(0);
            String urduTranslation=c.getString(1);
            String englishTranslation=c.getString(2);
            ayahs=new Ayah(ayah,urduTranslation,englishTranslation);
            ParahAyahs.add(ayahs);
        }
        return ParahAyahs;
    }

}
